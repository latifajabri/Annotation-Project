package com.ensa.gi4.Dao;

import com.ensa.gi4.datatabase.DataSource;
import com.ensa.gi4.modele.Materiel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MaterielDAOImp implements MaterielDAO{

@Autowired
    DataSource dataSource;

    @Override
    public void listerMateriels() {
        dataSource.getMaterial();

    }

    @Override
    public void ajouterMateriel(Materiel materiel) {

    }

    @Override
    public void supprimerMateriel(int id) {


    }
}
