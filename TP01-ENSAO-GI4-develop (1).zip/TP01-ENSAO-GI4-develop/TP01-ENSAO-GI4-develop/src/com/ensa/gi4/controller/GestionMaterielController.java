package com.ensa.gi4.controller;

import com.ensa.gi4.modele.Chaise;
import com.ensa.gi4.modele.Livre;
import com.ensa.gi4.modele.Materiel;
import com.ensa.gi4.service.api.GestionMaterielService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component
public class GestionMaterielController {
        @Autowired
        @Qualifier("materielService")
    private GestionMaterielService gestionMaterielService;


    public void listerMateriel() {
        gestionMaterielService.listerMateriel();
    }

    public void afficherMenu() throws InterruptedException {
        System.out.println("1- pour lister le matériel, entrer 1");
        System.out.println("2- pour ajouter un nouveau matériel, entrer 2");
        System.out.println("3- pour supprimer un  matériel, entrer 3");
        System.out.println("4- pour modifier un  matériel, entrer 4");
        System.out.println("5- pour allouer un  matériel, entrer 5");
        System.out.println("0- pour sortir de l'application, entrer 0");
        Scanner scanner = new Scanner(System.in);
        String next = scanner.next();
        if ("0".equals(next)) {
            sortirDeLApplication();
        } else if ("1".equals(next)) {
            listerMateriel();
        } else if ("2".equals(next)) {
            // ajouter nouveau matériel
            Materiel m=new Materiel() {
            };
            System.out.println("si vous voulez entrer livre taper 1 sinon taper 2");

            Scanner scanner1 = new Scanner(System.in);
            int  next1 = Integer.parseInt(scanner.next());
            switch (next1){
                case 1:
                  m  =new Livre();
                  break;
                case 2:
                    m=new Chaise();
                  break;
                default:
                    System.out.println("choix invalid ");

            }


            System.out.println("entrer le nom de votre materiel");
            Scanner s = new Scanner(System.in);
            String n = scanner.next();
            m.setName(n);



            gestionMaterielService.ajouterNouveauMateriel(m);
        }
        else if("3".equals(next)){
            System.out.println("entrer le nom du matriel ");
            Scanner s3 = new Scanner(System.in);
            String n3 = scanner.next();
            gestionMaterielService.supprimermateriel(n3);

        }
        else if("4".equals(next)){
            System.out.println("entrer le nom ancien ");
            Scanner s4 = new Scanner(System.in);
            String n4 = scanner.next();
            System.out.println("entrer le nouveau nom");
            Scanner s5 = new Scanner(System.in);
            String n5 = scanner.next();

            gestionMaterielService.modifiermateriel(n4,n5);

        }
        else if("5".equals(next)){


            gestionMaterielService.locat();

        }


        else {
            System.out.println("choix invalide");
        }
    }

    private void sortirDeLApplication() {
        System.exit(0);
    }

    public void setGestionMaterielService(GestionMaterielService gestionMaterielService) {
        // injection par accesseur
        this.gestionMaterielService = gestionMaterielService;
    }
}
