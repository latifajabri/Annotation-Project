package com.ensa.gi4.service.impl;

import com.ensa.gi4.dao.Dao;
import com.ensa.gi4.modele.Materiel;
import com.ensa.gi4.service.api.GestionMaterielService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@Component("materielService")
public class GestionMaterielServiceImpl implements GestionMaterielService {
    // bd goes here
@Autowired
    Dao dao;


    @Override
    public void init() {
        System.out.println("inititialisation du service");
    }

    @Override
    public void listerMateriel() {
        dao.listerMateriel();
    }

    @Override
    public void ajouterNouveauMateriel(Materiel materiel) {
        // à compléter
        dao.ajouterMateriel(materiel);
        System.out.println("L'ajout du matériel " + materiel.getName() + " effectué avec succès !");
    }

    @Override
    public void supprimermateriel(String nameService) {
        dao.supprimerMateriel(nameService);
    }

    @Override
    public void modifiermateriel(String name1, String name2) {
        dao.modifierMateriel(name1, name2);
    }

   @Override
    public void locat() throws InterruptedException {
        System.out.println(" to loan livre , entrer l");
        System.out.println(" to loan  chaise,enter c");
        //input user
        Scanner scanner = new Scanner(System.in);
        String next = scanner.next();
        if ("LL".equals(next)) {
            System.out.println("entrer nom");
            String name1 = String.valueOf(Integer.parseInt(scanner.next()));
            dao.allouerMateriel(name1);
        } else if ("LC".equals(next)) {
            System.out.println("entrer nom");
            String name2 = String.valueOf(Integer.parseInt(scanner.next()));
            dao.allouerMateriel(name2);

        }
    }

}