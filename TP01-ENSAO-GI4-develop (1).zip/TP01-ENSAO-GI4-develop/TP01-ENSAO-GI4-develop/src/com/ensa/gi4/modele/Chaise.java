package com.ensa.gi4.modele;

public class Chaise extends Materiel {
}
