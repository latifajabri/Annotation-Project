package com.ensa.gi4.modele;

public class Livre extends Materiel {
}
